class ModelResult:
    def __init__(self, modelName, modelResult):
        self.modelName = modelName
        self.modelResult = modelResult

class ModelResults:
    results = {}
